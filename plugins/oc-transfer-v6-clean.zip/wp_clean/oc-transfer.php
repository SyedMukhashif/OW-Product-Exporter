<?php
/*
Plugin Name: OpenCart to WooCommerce Transfer v6
Description: Transfer products from OpenCart to WooCommerce
Version: 6.0
Author: Custom Build
*/
if (!defined('ABSPATH')) exit;

add_action('plugins_loaded', 'oct_init');

function oct_init() {
    if (!class_exists('WooCommerce')) {
        add_action('admin_notices', 'oct_wc_notice');
        return;
    }
    add_action('admin_menu', 'oct_menu');
    add_action('wp_ajax_oct_test',       'oct_ajax_test');
    add_action('wp_ajax_oct_stats',      'oct_ajax_stats');
    add_action('wp_ajax_oct_wp_stats',   'oct_ajax_wp_stats');
    add_action('wp_ajax_oct_categories', 'oct_ajax_categories');
    add_action('wp_ajax_oct_products',   'oct_ajax_products');
    add_action('wp_ajax_oct_delete_all', 'oct_ajax_delete_all');
}

function oct_wc_notice() {
    echo '<div class="notice notice-error"><p>OC Transfer: WooCommerce must be active.</p></div>';
}

function oct_menu() {
    add_menu_page('OC Transfer', 'OC Transfer', 'manage_options', 'oct-transfer', 'oct_page', 'dashicons-migrate', 58);
}

function oct_post($k, $d) {
    return isset($_POST[$k]) ? $_POST[$k] : $d;
}

function oct_api($ep, $params) {
    $url = rtrim(get_option('oct_url', ''), '/');
    $key = get_option('oct_key', '');
    if (empty($url)) {
        return array('error' => 'URL not set');
    }
    $query = http_build_query(array_merge(array('key' => $key), $params));
    $full  = $url . '/index.php?route=api/transfer/' . $ep . '&' . $query;
    $resp  = wp_remote_get($full, array(
        'timeout'    => 120,
        'sslverify'  => false,
        'user-agent' => 'WP-OC-Transfer/6.0',
        'headers'    => array('Accept' => 'application/json'),
    ));
    if (is_wp_error($resp)) {
        return array('error' => $resp->get_error_message());
    }
    $code = (int) wp_remote_retrieve_response_code($resp);
    if ($code === 401) {
        return array('error' => 'Auth failed - check API key');
    }
    if ($code !== 200) {
        return array('error' => 'HTTP error ' . $code);
    }
    $body = wp_remote_retrieve_body($resp);
    if (empty(trim($body))) {
        return array('error' => 'Empty response');
    }
    $data = json_decode($body, true);
    if (json_last_error() !== JSON_ERROR_NONE) {
        return array('error' => 'Bad JSON: ' . substr(strip_tags($body), 0, 100));
    }
    return $data;
}

function oct_nonce_check() {
    if (!check_ajax_referer('oct_nonce', 'nonce', false)) {
        wp_send_json(array('success' => false, 'message' => 'Security check failed'), 403);
        exit;
    }
}

function oct_ajax_test() {
    oct_nonce_check();
    if (!current_user_can('manage_options')) {
        wp_die('Forbidden');
    }
    $url = esc_url_raw(trim(oct_post('url', '')));
    $key = sanitize_text_field(trim(oct_post('key', '')));
    if (empty($url)) {
        wp_send_json(array('success' => false, 'error' => 'Enter OpenCart URL'));
        return;
    }
    update_option('oct_url', $url);
    update_option('oct_key', $key);
    $r = oct_api('index', array());
    if (isset($r['error'])) {
        wp_send_json(array('success' => false, 'error' => $r['error']));
        return;
    }
    $store   = isset($r['store'])   ? $r['store']   : '';
    $version = isset($r['version']) ? $r['version'] : '';
    wp_send_json(array('success' => true, 'store' => $store, 'version' => $version));
}

function oct_ajax_stats() {
    oct_nonce_check();
    if (!current_user_can('manage_options')) {
        wp_die('Forbidden');
    }
    $r = oct_api('stats', array());
    if (isset($r['error'])) {
        wp_send_json(array('success' => false, 'error' => $r['error']));
        return;
    }
    wp_send_json(array('success' => true, 'categories' => (int) $r['categories'], 'products' => (int) $r['products']));
}

function oct_ajax_wp_stats() {
    oct_nonce_check();
    if (!current_user_can('manage_options')) {
        wp_die('Forbidden');
    }
    $p     = wp_count_posts('product');
    $pub   = isset($p->publish) ? (int) $p->publish : 0;
    $drft  = isset($p->draft)   ? (int) $p->draft   : 0;
    $priv  = isset($p->private) ? (int) $p->private : 0;
    $total = $pub + $drft + $priv;
    $cats  = wp_count_terms(array('taxonomy' => 'product_cat', 'hide_empty' => false));
    $cats  = is_wp_error($cats) ? 0 : (int) $cats;
    wp_send_json(array('success' => true, 'products' => $total, 'categories' => $cats));
}

function oct_ajax_categories() {
    oct_nonce_check();
    if (!current_user_can('manage_options')) {
        wp_die('Forbidden');
    }
    set_time_limit(300);
    $page   = max(1, (int) oct_post('page', 1));
    $result = oct_api('categories', array('page' => $page, 'limit' => 500));
    if (isset($result['error'])) {
        wp_send_json(array('success' => false, 'message' => $result['error']));
        return;
    }
    $cats  = isset($result['categories']) ? $result['categories'] : array();
    $pages = isset($result['pages'])      ? (int) $result['pages'] : 1;
    $total = isset($result['total'])      ? (int) $result['total'] : 0;
    if (empty($cats) || !is_array($cats)) {
        wp_send_json(array('success' => true, 'imported' => 0, 'skipped' => 0,
            'page' => $page, 'pages' => $pages, 'total' => $total,
            'message' => 'Page ' . $page . ': 0 categories'));
        return;
    }
    global $wpdb;
    $emap = array();
    $rows = $wpdb->get_results("SELECT term_id, meta_value FROM " . $wpdb->termmeta . " WHERE meta_key = '_oc_category_id'");
    foreach ($rows as $row) {
        $emap[(int) $row->meta_value] = (int) $row->term_id;
    }
    $imported = 0;
    $skipped  = 0;
    foreach ($cats as $cat) {
        if (empty($cat['name'])) {
            continue;
        }
        $oc_id  = (int) $cat['id'];
        $oc_pid = (int) $cat['parent_id'];
        $par_id = ($oc_pid > 0 && isset($emap[$oc_pid])) ? $emap[$oc_pid] : 0;
        if (isset($emap[$oc_id])) {
            wp_update_term($emap[$oc_id], 'product_cat', array(
                'description' => $cat['description'],
                'parent'      => $par_id,
            ));
            $skipped++;
            continue;
        }
        $slug = 'oc-cat-' . $oc_id;
        $term = wp_insert_term($cat['name'], 'product_cat', array(
            'description' => $cat['description'],
            'parent'      => $par_id,
            'slug'        => $slug,
        ));
        if (is_wp_error($term)) {
            if ($term->get_error_code() === 'term_exists') {
                $eid = $term->get_error_data('term_exists');
                $eid = is_array($eid) ? (int) $eid['term_id'] : (int) $eid;
                if ($eid > 0) {
                    update_term_meta($eid, '_oc_category_id', $oc_id);
                    $emap[$oc_id] = $eid;
                }
            }
            $skipped++;
            continue;
        }
        $wid = (int) $term['term_id'];
        update_term_meta($wid, '_oc_category_id', $oc_id);
        $emap[$oc_id] = $wid;
        clean_term_cache($wid, 'product_cat');
        delete_option('product_cat_children');
        if (!empty($cat['image'])) {
            $aid = oct_sideload_image($cat['image'], $cat['name']);
            if ($aid) {
                update_term_meta($wid, 'thumbnail_id', $aid);
            }
        }
        $imported++;
    }
    $msg = 'Page ' . $page . '/' . $pages . ': ' . $imported . ' new, ' . $skipped . ' updated';
    wp_send_json(array('success' => true, 'imported' => $imported, 'skipped' => $skipped,
        'page' => $page, 'pages' => $pages, 'total' => $total, 'message' => $msg));
}

function oct_ajax_products() {
    oct_nonce_check();
    if (!current_user_can('manage_options')) {
        wp_die('Forbidden');
    }
    set_time_limit(300);
    $page   = max(1, (int) oct_post('page', 1));
    $result = oct_api('products', array('page' => $page, 'limit' => 50));
    if (isset($result['error'])) {
        wp_send_json(array('success' => false, 'message' => $result['error']));
        return;
    }
    $prods = isset($result['products']) ? $result['products'] : array();
    $pages = isset($result['pages'])    ? (int) $result['pages'] : 1;
    $total = isset($result['total'])    ? (int) $result['total'] : 0;
    if (empty($prods) || !is_array($prods)) {
        wp_send_json(array('success' => true, 'imported' => 0, 'updated' => 0, 'failed' => 0,
            'errors' => array(), 'page' => $page, 'pages' => $pages, 'total' => $total,
            'message' => 'Page ' . $page . ': 0 products'));
        return;
    }
    $imported = 0;
    $updated  = 0;
    $failed   = 0;
    $errors   = array();
    $flush    = array();
    $allowed  = array_merge(wp_kses_allowed_html('post'), array(
        'span' => array('style' => true, 'class' => true),
    ));
    foreach ($prods as $product) {
        try {
            if (empty($product['name'])) {
                $failed++;
                continue;
            }
            $existing_id = wc_get_product_id_by_sku($product['sku']);
            if ($existing_id === false) {
                $existing_id = 0;
            }
            if (!$existing_id && !empty($product['id'])) {
                global $wpdb;
                $found = $wpdb->get_var($wpdb->prepare(
                    "SELECT post_id FROM " . $wpdb->postmeta . " WHERE meta_key='_oc_product_id' AND meta_value=%s LIMIT 1",
                    $product['id']
                ));
                if ($found) {
                    $existing_id = (int) $found;
                }
            }
            $post_data = array(
                'post_title'   => sanitize_text_field($product['name']),
                'post_content' => wp_kses($product['description'], $allowed),
                'post_excerpt' => wp_kses($product['short_description'], $allowed),
                'post_status'  => 'publish',
                'post_type'    => 'product',
            );
            if ($existing_id > 0) {
                $post_data['ID'] = $existing_id;
                $pid = wp_update_post($post_data, true);
                if (!is_wp_error($pid)) {
                    $updated++;
                }
            } else {
                $pid = wp_insert_post($post_data, true);
                if (!is_wp_error($pid)) {
                    $imported++;
                }
            }
            if (is_wp_error($pid)) {
                $errors[] = substr($product['name'], 0, 40) . ': ' . $pid->get_error_message();
                $failed++;
                continue;
            }
            update_post_meta($pid, '_oc_product_id', $product['id']);
            $price = (float) $product['price'];
            $sale  = ($product['sale_price'] !== null && $product['sale_price'] !== '') ? (float) $product['sale_price'] : null;
            $active = ($sale !== null && $sale < $price) ? $sale : $price;
            update_post_meta($pid, '_regular_price',     $price);
            update_post_meta($pid, '_price',             $active);
            update_post_meta($pid, '_sku',               $product['sku']);
            update_post_meta($pid, '_stock_quantity',    (int) $product['stock_quantity']);
            update_post_meta($pid, '_stock',             (int) $product['stock_quantity']);
            update_post_meta($pid, '_manage_stock',      'yes');
            update_post_meta($pid, '_weight',            (float) $product['weight']);
            update_post_meta($pid, '_visibility',        'visible');
            update_post_meta($pid, '_virtual',           'no');
            update_post_meta($pid, '_downloadable',      'no');
            update_post_meta($pid, '_sold_individually', 'no');
            if ($sale !== null) {
                update_post_meta($pid, '_sale_price', $sale);
            }
            $stock_status = ($product['stock_status'] === 'instock') ? 'instock' : 'outofstock';
            update_post_meta($pid, '_stock_status', $stock_status);
            wp_set_object_terms($pid, 'simple', 'product_type');
            $term_ids = array();
            foreach ($product['categories'] as $cat_name) {
                if (empty($cat_name)) {
                    continue;
                }
                $t = get_term_by('name', $cat_name, 'product_cat');
                if ($t) {
                    $term_ids[] = (int) $t->term_id;
                } else {
                    $nt = wp_insert_term($cat_name, 'product_cat');
                    if (!is_wp_error($nt)) {
                        $term_ids[] = (int) $nt['term_id'];
                    }
                }
            }
            if (!empty($term_ids)) {
                wp_set_object_terms($pid, array_unique($term_ids), 'product_cat');
            }
            if (!empty($product['tags'])) {
                $clean_tags = array_values(array_filter(array_map('sanitize_text_field', $product['tags'])));
                if (!empty($clean_tags)) {
                    wp_set_object_terms($pid, $clean_tags, 'product_tag');
                }
            }
            if (!empty($product['brand']) && taxonomy_exists('pwb-brand')) {
                $bn = sanitize_text_field($product['brand']);
                $bt = get_term_by('name', $bn, 'pwb-brand');
                if (!$bt) {
                    $nb = wp_insert_term($bn, 'pwb-brand');
                    if (!is_wp_error($nb)) {
                        wp_set_object_terms($pid, array($nb['term_id']), 'pwb-brand');
                    }
                } else {
                    wp_set_object_terms($pid, array($bt->term_id), 'pwb-brand');
                }
            }
            if (!empty($product['images'])) {
                $has_thumb = (int) get_post_thumbnail_id($pid) > 0;
                $gallery   = array();
                foreach ($product['images'] as $idx => $img_url) {
                    if (empty($img_url)) {
                        continue;
                    }
                    $aid = oct_sideload_image($img_url, $product['name']);
                    if (!$aid) {
                        continue;
                    }
                    if ($idx === 0 && !$has_thumb) {
                        set_post_thumbnail($pid, $aid);
                        $has_thumb = true;
                    } elseif ($idx > 0) {
                        $gallery[] = $aid;
                    }
                }
                if (!empty($gallery)) {
                    $eg   = get_post_meta($pid, '_product_image_gallery', true);
                    $eids = array_filter(explode(',', $eg));
                    update_post_meta($pid, '_product_image_gallery', implode(',', array_unique(array_merge($eids, $gallery))));
                }
            }
            if (!empty($product['meta_title'])) {
                update_post_meta($pid, '_yoast_wpseo_title',  $product['meta_title']);
                update_post_meta($pid, 'rank_math_title',      $product['meta_title']);
            }
            if (!empty($product['meta_description'])) {
                update_post_meta($pid, '_yoast_wpseo_metadesc', $product['meta_description']);
                update_post_meta($pid, 'rank_math_description',  $product['meta_description']);
            }
            $flush[] = $pid;
        } catch (Exception $e) {
            $name    = isset($product['name']) ? substr($product['name'], 0, 40) : 'unknown';
            $errors[] = $name . ': ' . $e->getMessage();
            $failed++;
        }
    }
    foreach ($flush as $fid) {
        wc_delete_product_transients($fid);
    }
    $msg = 'Page ' . $page . '/' . $pages . ': ' . $imported . ' new, ' . $updated . ' updated';
    if ($failed > 0) {
        $msg .= ', ' . $failed . ' failed';
    }
    wp_send_json(array('success' => true, 'imported' => $imported, 'updated' => $updated,
        'failed' => $failed, 'errors' => array_slice($errors, 0, 5),
        'page' => $page, 'pages' => $pages, 'total' => $total, 'message' => $msg));
}

function oct_ajax_delete_all() {
    oct_nonce_check();
    if (!current_user_can('manage_options')) {
        wp_die('Forbidden');
    }
    $batch = max(1, (int) oct_post('batch', 200));
    $ids   = get_posts(array(
        'post_type'      => 'product',
        'posts_per_page' => $batch,
        'offset'         => 0,
        'fields'         => 'ids',
        'post_status'    => array('publish', 'draft', 'private', 'pending'),
    ));
    $deleted = 0;
    foreach ($ids as $id) {
        wp_delete_post($id, true);
        $deleted++;
    }
    $c   = wp_count_posts('product');
    $pub = isset($c->publish) ? (int) $c->publish : 0;
    $drft = isset($c->draft)  ? (int) $c->draft   : 0;
    $priv = isset($c->private)? (int) $c->private : 0;
    $rem  = $pub + $drft + $priv;
    if ($rem <= 0) {
        $terms = get_terms(array('taxonomy' => 'product_cat', 'hide_empty' => false));
        if (!is_wp_error($terms)) {
            foreach ($terms as $t) {
                if ($t->slug !== 'uncategorized') {
                    wp_delete_term($t->term_id, 'product_cat');
                }
            }
        }
    }
    wp_send_json(array('success' => true, 'deleted' => $deleted, 'remaining' => $rem, 'done' => $rem <= 0));
}

function oct_sideload_image($url, $title) {
    if (empty($url)) {
        return false;
    }
    $hash = md5($url);
    global $wpdb;
    $ex = $wpdb->get_var($wpdb->prepare(
        "SELECT post_id FROM " . $wpdb->postmeta . " WHERE meta_key='_oct_img_hash' AND meta_value=%s LIMIT 1",
        $hash
    ));
    if ($ex) {
        return (int) $ex;
    }
    require_once ABSPATH . 'wp-admin/includes/media.php';
    require_once ABSPATH . 'wp-admin/includes/file.php';
    require_once ABSPATH . 'wp-admin/includes/image.php';
    $tmp = download_url($url, 60);
    if (is_wp_error($tmp)) {
        return false;
    }
    $mime = false;
    if (function_exists('mime_content_type')) {
        $mime = mime_content_type($tmp);
    }
    if ($mime !== false && strpos($mime, 'image/') !== 0) {
        @unlink($tmp);
        return false;
    }
    $fn = basename(parse_url($url, PHP_URL_PATH));
    if (empty($fn) || !preg_match('/\.(jpg|jpeg|png|gif|webp)$/i', $fn)) {
        $fn = 'img-' . $hash . '.jpg';
    }
    $fa = array('name' => $fn, 'tmp_name' => $tmp);
    $id = media_handle_sideload($fa, 0, $title);
    @unlink($tmp);
    if (is_wp_error($id)) {
        return false;
    }
    update_post_meta($id, '_oct_img_hash', $hash);
    return (int) $id;
}

function oct_page() {
    $url   = get_option('oct_url', '');
    $key   = get_option('oct_key', 'AMB_TRANSFER_2026');
    $nonce = wp_create_nonce('oct_nonce');
    $ajax  = admin_url('admin-ajax.php');
    echo '<div class="wrap">';
    echo '<style>';
    echo '.oct-card{background:#fff;border-radius:8px;padding:24px;margin:14px 0;box-shadow:0 2px 8px rgba(0,0,0,.08)}';
    echo '.oct-btn{padding:9px 20px;border:none;border-radius:6px;cursor:pointer;font-size:14px;font-weight:600;margin:4px 2px}';
    echo '.oct-btn:hover{opacity:.85}.oct-btn:disabled{opacity:.4;cursor:not-allowed}';
    echo '.b-blue{background:#2196F3;color:#fff}.b-green{background:#4CAF50;color:#fff}';
    echo '.b-red{background:#f44336;color:#fff}.b-orange{background:#FF9800;color:#fff}';
    echo '.b-purple{background:#9c27b0;color:#fff}';
    echo '.oct-log{background:#111;color:#33ff33;font-family:monospace;font-size:12px;padding:14px;border-radius:6px;height:280px;overflow-y:auto;margin-top:10px;line-height:1.7}';
    echo '.oct-bw{background:#e0e0e0;border-radius:20px;height:18px;overflow:hidden;margin:8px 0}';
    echo '.oct-bar{background:#4CAF50;height:100%;border-radius:20px;transition:width .3s;width:0%}';
    echo '.s-ok{background:#e8f5e9;color:#2e7d32;padding:9px 14px;border-radius:6px;margin:6px 0;font-weight:600}';
    echo '.s-err{background:#ffebee;color:#c62828;padding:9px 14px;border-radius:6px;margin:6px 0;font-weight:600}';
    echo '.s-info{background:#e3f2fd;color:#1565c0;padding:9px 14px;border-radius:6px;margin:6px 0;font-weight:600}';
    echo '.oct-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:10px;margin-top:10px}';
    echo '.oct-stat{background:#f5f5f5;border-radius:8px;padding:12px;text-align:center}';
    echo '.oct-num{font-size:24px;font-weight:700;color:#1565c0}.oct-lbl{font-size:11px;color:#888;margin-top:3px}';
    echo 'input[type=text],input[type=url]{width:100%;padding:9px 12px;border:1px solid #ddd;border-radius:6px;font-size:14px;margin:4px 0;box-sizing:border-box}';
    echo '.oct-warn{background:#fff3e0;border-left:4px solid #FF9800;padding:9px 14px;border-radius:0 6px 6px 0;font-size:13px;color:#7d4600;margin:8px 0}';
    echo '</style>';
    echo '<h1>OpenCart to WooCommerce Transfer v6</h1>';
    echo '<div class="oct-card">';
    echo '<h3>Step 1 - Connect to OpenCart</h3>';
    echo '<label>OpenCart Store URL</label>';
    echo '<input type="url" id="oct_url" value="' . esc_attr($url) . '" placeholder="https://amb.gr">';
    echo '<label>API Key</label>';
    echo '<input type="text" id="oct_key" value="' . esc_attr($key) . '" placeholder="AMB_TRANSFER_2026">';
    echo '<div style="margin-top:10px">';
    echo '<button class="oct-btn b-blue" onclick="testConn()">Test Connection</button>';
    echo '<button class="oct-btn b-orange" onclick="loadStats()">Refresh Stats</button>';
    echo '</div>';
    echo '<div id="conn_st"></div>';
    echo '<div class="oct-grid" id="sgrid" style="display:none">';
    echo '<div class="oct-stat"><div class="oct-num" id="s1">-</div><div class="oct-lbl">OC Categories</div></div>';
    echo '<div class="oct-stat"><div class="oct-num" id="s2">-</div><div class="oct-lbl">OC Products</div></div>';
    echo '<div class="oct-stat"><div class="oct-num" id="s3">-</div><div class="oct-lbl">WP Categories</div></div>';
    echo '<div class="oct-stat"><div class="oct-num" id="s4">-</div><div class="oct-lbl">WP Products</div></div>';
    echo '</div>';
    echo '</div>';
    echo '<div class="oct-card">';
    echo '<h3>Step 2 - Transfer (Categories first, then Products)</h3>';
    echo '<div class="oct-warn">Always import Categories first! Safe to re-run - no duplicates created.</div>';
    echo '<div style="margin:10px 0">';
    echo '<button class="oct-btn b-green" id="bc" onclick="transfer(\'categories\')">Import Categories</button>';
    echo '<button class="oct-btn b-green" id="bp" onclick="transfer(\'products\')">Import Products</button>';
    echo '<button class="oct-btn b-purple" id="br" onclick="doResume()" style="display:none">Resume (page <span id="rp">?</span>)</button>';
    echo '<button class="oct-btn b-red" id="bd" onclick="deleteAll()">Delete All</button>';
    echo '</div>';
    echo '<div class="oct-bw"><div class="oct-bar" id="prog"></div></div>';
    echo '<div id="ptxt" style="font-size:12px;color:#888;text-align:center;height:16px;margin-bottom:4px"></div>';
    echo '<div id="oct_log" class="oct-log">&gt; Ready. Test connection then click Import Categories.</div>';
    echo '</div>';
    $nonce_js = esc_js($nonce);
    $ajax_js  = esc_js($ajax);
    echo '<script>';
    echo 'var N="' . $nonce_js . '",A="' . $ajax_js . '";';
    echo 'var running=false,retries=0;';
    echo 'function xlog(m,c){c=c||"#33ff33";var e=document.getElementById("oct_log"),ts=new Date().toTimeString().slice(0,8);e.innerHTML+="<span style=\'color:"+c+"\'>["+ts+"] "+String(m).replace(/</g,"&lt;").replace(/>/g,"&gt;")+"</span><br>";e.scrollTop=e.scrollHeight;}';
    echo 'function setSt(m,t){var cls={ok:"s-ok",err:"s-err",info:"s-info"}[t]||"s-info";document.getElementById("conn_st").innerHTML="<div class=\'"+cls+"\'>" + m + "</div>";}';
    echo 'function setProg(p,t){var b=document.getElementById("prog");b.style.width=Math.min(100,p)+"%";b.style.background=p>=100?"#4CAF50":"#2196F3";document.getElementById("ptxt").textContent=t||"";}';
    echo 'function post(a,d){d=d||{};var b=new URLSearchParams(Object.assign({action:a,nonce:N,url:document.getElementById("oct_url").value.trim(),key:document.getElementById("oct_key").value.trim()},d));return fetch(A,{method:"POST",headers:{"Content-Type":"application/x-www-form-urlencoded"},body:b.toString()}).then(function(r){if(!r.ok)throw new Error("HTTP "+r.status);return r.json();});}';
    echo 'function sleep(ms){return new Promise(function(r){setTimeout(r,ms);});}';
    echo 'async function testConn(){setSt("Testing...","info");try{var r=await post("oct_test");if(r.success){setSt("Connected: "+r.store+" (OpenCart "+r.version+")","ok");loadStats();}else setSt("Failed: "+(r.error||r.message||"Unknown"),"err");}catch(e){setSt("Error: "+e.message,"err");}}';
    echo 'async function loadStats(){try{var oc=await post("oct_stats");if(oc.success){document.getElementById("s1").textContent=oc.categories;document.getElementById("s2").textContent=oc.products;document.getElementById("sgrid").style.display="grid";}var wp=await post("oct_wp_stats");if(wp.success){document.getElementById("s3").textContent=wp.categories;document.getElementById("s4").textContent=wp.products;}}catch(e){xlog("Stats error: "+e.message,"#ff8800");}}';
    echo 'async function transfer(type,sp){';
    echo '  if(running){xlog("Already running!","#ff8800");return;}';
    echo '  running=true;retries=0;';
    echo '  var bi=type==="categories"?"bc":"bp";';
    echo '  document.getElementById(bi).disabled=true;';
    echo '  document.getElementById("br").style.display="none";';
    echo '  xlog("Starting "+type+"...","#00aaff");';
    echo '  var page=sp||1,pages=9999,done={i:0,u:0,f:0};';
    echo '  try{';
    echo '    while(page<=pages){';
    echo '      var res;';
    echo '      try{res=await post("oct_"+type,{page:String(page)});retries=0;}';
    echo '      catch(e){retries++;if(retries<=3){xlog("Retry "+retries+"/3: "+e.message,"#ff8800");await sleep(2000*retries);continue;}saveR(type,page);xlog("Max retries. Click Resume from page "+page,"#ff4444");break;}';
    echo '      if(!res||!res.success){saveR(type,page);xlog("Error: "+(res?res.message:"No response"),"#ff4444");break;}';
    echo '      pages=parseInt(res.pages)||1;done.i+=parseInt(res.imported)||0;done.u+=parseInt(res.updated)||0;done.f+=parseInt(res.failed)||0;';
    echo '      var pct=Math.round((page/pages)*100);setProg(pct,pct+"% - "+res.message);xlog(res.message);';
    echo '      if(res.errors&&res.errors.length)res.errors.forEach(function(e){xlog("  ! "+e,"#ff8800");});';
    echo '      page++;await sleep(300);';
    echo '    }';
    echo '    if(page>pages){setProg(100,"Done! "+done.i+" new, "+done.u+" updated, "+done.f+" failed");xlog("Complete! "+done.i+" imported, "+done.u+" updated, "+done.f+" failed","#00ff88");clearR();loadStats();}';
    echo '  }finally{running=false;document.getElementById(bi).disabled=false;}';
    echo '}';
    echo 'function saveR(t,p){try{localStorage.setItem("oct_rt",t);localStorage.setItem("oct_rp",p);}catch(e){}document.getElementById("rp").textContent=p;document.getElementById("br").style.display="inline-block";}';
    echo 'function clearR(){try{localStorage.removeItem("oct_rt");localStorage.removeItem("oct_rp");}catch(e){}document.getElementById("br").style.display="none";}';
    echo 'function doResume(){try{var t=localStorage.getItem("oct_rt"),p=parseInt(localStorage.getItem("oct_rp"))||1;if(t)transfer(t,p);}catch(e){}}';
    echo 'async function deleteAll(){';
    echo '  if(!confirm("Delete ALL products and categories? Cannot undo!"))return;';
    echo '  if(running){xlog("Stop transfer first!","#ff8800");return;}';
    echo '  running=true;xlog("Deleting...","#ff8800");';
    echo '  try{var td=0;while(true){var r=await post("oct_delete_all",{batch:"200"});td+=r.deleted||0;setProg(r.done?100:50,"Deleted "+td+"...");xlog("Deleted: "+r.deleted+", remaining: "+r.remaining);if(r.done)break;await sleep(200);}xlog("Done! "+td+" deleted","#00ff88");setProg(100,"Deleted "+td);loadStats();}';
    echo '  finally{running=false;}';
    echo '}';
    echo 'document.addEventListener("DOMContentLoaded",function(){try{var t=localStorage.getItem("oct_rt"),p=localStorage.getItem("oct_rp");if(t&&p){document.getElementById("rp").textContent=p;document.getElementById("br").style.display="inline-block";xlog("Interrupted at page "+p+". Click Resume.","#ff8800");}}catch(e){}});';
    echo '</script>';
    echo '</div>';
}
