<?php
class ControllerApiTransfer extends Controller {

    private $secret  = 'AMB_TRANSFER_2026';
    private $lang_id = null;

    private function auth() {
        $key = isset($this->request->get['key']) ? trim($this->request->get['key']) : '';
        // BUG-OC-2 FIX: Correct fallback when hash_equals unavailable
        $ok = function_exists('hash_equals') ? hash_equals($this->secret, $key) : ($this->secret === $key);
        if (!$ok) {
            if (ob_get_level()) ob_end_clean();
            $this->response->addHeader('HTTP/1.1 401 Unauthorized');
            $this->response->addHeader('Content-Type: application/json; charset=UTF-8');
            $this->response->setOutput(json_encode(array('error' => 'Unauthorized')));
            return false;
        }
        return true;
    }

    private function baseUrl() {
        $https = false;
        if (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') $https = true;
        if (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && $_SERVER['HTTP_X_FORWARDED_PROTO'] === 'https') $https = true;
        if (!empty($_SERVER['SERVER_PORT']) && (int)$_SERVER['SERVER_PORT'] === 443) $https = true;
        $host = isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : $_SERVER['SERVER_NAME'];
        return ($https ? 'https' : 'http') . '://' . $host;
    }

    private function sendJson($data) {
        if (ob_get_level()) ob_end_clean();
        $this->response->addHeader('Content-Type: application/json; charset=UTF-8');
        $this->response->addHeader('Access-Control-Allow-Origin: *');
        $this->response->addHeader('Cache-Control: no-cache, no-store, must-revalidate');
        $flags = 0;
        if (defined('JSON_UNESCAPED_UNICODE')) $flags |= JSON_UNESCAPED_UNICODE;
        if (defined('JSON_UNESCAPED_SLASHES')) $flags |= JSON_UNESCAPED_SLASHES;
        $this->response->setOutput(json_encode($data, $flags));
    }

    private function buildImageUrl($image) {
        if (empty($image)) return '';
        $image = ltrim($image, '/');
        $path  = (strpos($image, 'image/') === 0) ? substr($image, 6) : $image;
        $segs  = array();
        foreach (explode('/', $path) as $seg) {
            if ($seg !== '') $segs[] = rawurlencode(rawurldecode($seg));
        }
        return $this->baseUrl() . '/image/' . implode('/', $segs);
    }

    private function safe($arr, $key, $default = '') {
        return (isset($arr[$key]) && $arr[$key] !== null) ? $arr[$key] : $default;
    }

    private function decodeHtml($text) {
        if (empty($text)) return '';
        $prev = null;
        while ($prev !== $text) { $prev = $text; $text = html_entity_decode($text, ENT_QUOTES, 'UTF-8'); }
        return $text;
    }

    // BUG-OC-6 FIX: Strip OpenCart placeholder descriptions
    private function cleanDesc($text) {
        if (empty($text)) return '';
        $text = trim($text);
        if (stripos($text, 'The category description can be positioned here') !== false) return '';
        if (stripos($text, 'category description can be positioned') !== false) return '';
        return $text;
    }

    private function getLangId() {
        if ($this->lang_id !== null) return $this->lang_id;
        $code = $this->config->get('config_language');
        if (!empty($code)) {
            $q = $this->db->query("SELECT language_id FROM " . DB_PREFIX . "language WHERE code = '" . $this->db->escape($code) . "' AND status = 1 LIMIT 1");
            if (!empty($q->row)) { $this->lang_id = (int)$q->row['language_id']; return $this->lang_id; }
        }
        // BUG-OC-3 FIX: Count only non-empty names
        $q = $this->db->query("SELECT language_id, COUNT(*) as cnt FROM " . DB_PREFIX . "category_description WHERE name IS NOT NULL AND name != '' GROUP BY language_id ORDER BY cnt DESC LIMIT 1");
        $this->lang_id = !empty($q->row) ? (int)$q->row['language_id'] : 1;
        return $this->lang_id;
    }

    public function index() {
        if (!$this->auth()) return;
        $this->sendJson(array('status' => 'ok', 'store' => $this->config->get('config_name'), 'version' => VERSION, 'php' => PHP_VERSION, 'language_id' => $this->getLangId()));
    }

    public function stats() {
        if (!$this->auth()) return;
        set_time_limit(0);
        $lid = $this->getLangId();
        // BUG-OC-3+OC-5 FIX: Count named categories only; both use status=1 for products
        $cats  = (int)$this->db->query("SELECT COUNT(DISTINCT c.category_id) AS total FROM " . DB_PREFIX . "category c INNER JOIN " . DB_PREFIX . "category_description cd ON c.category_id = cd.category_id AND cd.language_id = '" . (int)$lid . "' WHERE cd.name IS NOT NULL AND cd.name != ''")->row['total'];
        $prods = (int)$this->db->query("SELECT COUNT(*) AS total FROM " . DB_PREFIX . "product WHERE status = 1")->row['total'];
        $this->sendJson(array('categories' => $cats, 'products' => $prods, 'language_id' => $lid));
    }

    public function categories() {
        if (!$this->auth()) return;
        set_time_limit(0);
        ini_set('memory_limit', '512M');

        $lid   = $this->getLangId();
        $page  = max(1, (int)$this->safe($this->request->get, 'page', 1));
        $limit = min(500, max(1, (int)$this->safe($this->request->get, 'limit', 500)));
        $start = ($page - 1) * $limit;

        // BUG-OC-3 FIX: Count matches what we actually return
        $total = (int)$this->db->query("SELECT COUNT(DISTINCT c.category_id) AS total FROM " . DB_PREFIX . "category c INNER JOIN " . DB_PREFIX . "category_description cd ON c.category_id = cd.category_id AND cd.language_id = '" . (int)$lid . "' WHERE cd.name IS NOT NULL AND cd.name != ''")->row['total'];
        $pages = $total > 0 ? (int)ceil($total / $limit) : 1;

        // BUG-OC-4 FIX: INNER JOIN + stable ORDER BY
        $query = $this->db->query("
            SELECT c.category_id, c.parent_id, c.image, c.sort_order, c.status, cd.name, cd.description
            FROM " . DB_PREFIX . "category c
            INNER JOIN " . DB_PREFIX . "category_description cd ON c.category_id = cd.category_id AND cd.language_id = '" . (int)$lid . "'
            WHERE cd.name IS NOT NULL AND cd.name != ''
            ORDER BY c.parent_id ASC, c.sort_order ASC, c.category_id ASC
            LIMIT " . (int)$start . ", " . (int)$limit
        );

        $data = array();
        // BUG-OC-7 FIX: Check rows exist
        if (!empty($query->rows)) {
            foreach ($query->rows as $row) {
                $name = trim($this->safe($row, 'name', ''));
                if (empty($name)) continue;
                $data[] = array(
                    'id'          => (int)$row['category_id'],
                    'parent_id'   => (int)$row['parent_id'],
                    'name'        => $name,
                    'description' => strip_tags($this->decodeHtml($this->cleanDesc($this->safe($row, 'description', '')))),
                    'image'       => $this->buildImageUrl($this->safe($row, 'image', '')),
                    'sort_order'  => (int)$row['sort_order'],
                    'status'      => (int)$row['status'],
                );
            }
        }

        $this->sendJson(array('total' => $total, 'page' => $page, 'limit' => $limit, 'pages' => $pages, 'categories' => $data));
    }

    public function products() {
        if (!$this->auth()) return;
        set_time_limit(0);
        ini_set('memory_limit', '512M');

        $lid   = $this->getLangId();
        $page  = max(1, (int)$this->safe($this->request->get, 'page', 1));
        $limit = min(100, max(1, (int)$this->safe($this->request->get, 'limit', 50)));
        $start = ($page - 1) * $limit;

        $total = (int)$this->db->query("SELECT COUNT(*) AS total FROM " . DB_PREFIX . "product WHERE status = 1")->row['total'];
        $pages = $total > 0 ? (int)ceil($total / $limit) : 1;

        // BUG-OC-4 FIX: ORDER BY product_id for stable pagination
        $query = $this->db->query("
            SELECT p.product_id, p.model, p.sku, p.price, p.quantity,
                   p.image, p.weight, p.sort_order, p.status, p.manufacturer_id,
                   pd.name, pd.description, pd.tag, pd.meta_title, pd.meta_description,
                   m.name AS manufacturer_name
            FROM " . DB_PREFIX . "product p
            LEFT JOIN " . DB_PREFIX . "product_description pd ON p.product_id = pd.product_id AND pd.language_id = '" . (int)$lid . "'
            LEFT JOIN " . DB_PREFIX . "manufacturer m ON p.manufacturer_id = m.manufacturer_id
            WHERE p.status = 1
            ORDER BY p.product_id ASC
            LIMIT " . (int)$start . ", " . (int)$limit
        );

        // BUG-OC-7 FIX: Guard empty result
        if (empty($query->rows)) {
            $this->sendJson(array('total' => $total, 'page' => $page, 'limit' => $limit, 'pages' => $pages, 'products' => array()));
            return;
        }

        $pids  = array();
        foreach ($query->rows as $r) $pids[] = (int)$r['product_id'];
        $plist = implode(',', $pids);

        // Batch queries
        $img_q = $this->db->query("SELECT product_id, image FROM " . DB_PREFIX . "product_image WHERE product_id IN (" . $plist . ") ORDER BY product_id ASC, sort_order ASC");
        $extra = array();
        if (!empty($img_q->rows)) foreach ($img_q->rows as $r) $extra[(int)$r['product_id']][] = $r['image'];

        $cat_q = $this->db->query("SELECT ptc.product_id, cd.name FROM " . DB_PREFIX . "product_to_category ptc INNER JOIN " . DB_PREFIX . "category_description cd ON ptc.category_id = cd.category_id AND cd.language_id = '" . (int)$lid . "' WHERE ptc.product_id IN (" . $plist . ") AND cd.name IS NOT NULL AND cd.name != ''");
        $pcats = array();
        if (!empty($cat_q->rows)) foreach ($cat_q->rows as $r) if (!empty($r['name'])) $pcats[(int)$r['product_id']][] = $r['name'];

        $spec_q = $this->db->query("SELECT product_id, MIN(price) AS price FROM " . DB_PREFIX . "product_special WHERE product_id IN (" . $plist . ") AND (date_start = '0000-00-00' OR date_start <= NOW()) AND (date_end = '0000-00-00' OR date_end >= NOW()) GROUP BY product_id");
        $specs = array();
        if (!empty($spec_q->rows)) foreach ($spec_q->rows as $r) $specs[(int)$r['product_id']] = $r['price'];

        $seen = array();
        $data = array();
        foreach ($query->rows as $row) {
            $pid  = (int)$row['product_id'];
            $name = trim($this->safe($row, 'name', ''));
            if (empty($name)) continue;

            $sku = trim($this->safe($row, 'sku', ''));
            if (empty($sku)) $sku = trim($this->safe($row, 'model', ''));
            if (empty($sku)) $sku = 'PROD-' . $pid;
            $orig = $sku; $s = 1;
            while (isset($seen[$sku])) { $sku = $orig . '-' . $pid . ($s > 1 ? '-' . $s : ''); $s++; }
            $seen[$sku] = $pid;

            $images = array();
            $main   = $this->safe($row, 'image', '');
            if (!empty($main)) $images[] = $this->buildImageUrl($main);
            if (!empty($extra[$pid])) foreach ($extra[$pid] as $ei) { if (!empty($ei)) { $u = $this->buildImageUrl($ei); if (!in_array($u, $images)) $images[] = $u; } }

            $cats = isset($pcats[$pid]) ? array_values(array_filter($pcats[$pid])) : array();
            if (empty($cats)) $cats = array('Uncategorized');

            $brand = trim($this->safe($row, 'manufacturer_name', ''));
            $tags  = array();
            if (!empty($brand)) $tags[] = $brand;
            $rt = trim($this->safe($row, 'tag', ''));
            if (!empty($rt)) foreach (explode(',', $rt) as $t) { $t = trim($t); if ($t && !in_array($t, $tags)) $tags[] = $t; }

            // BUG-OC-5 FIX: Use null for no sale (not empty string) to distinguish from 0
            $sale  = isset($specs[$pid]) ? (float)$specs[$pid] : null;
            $price = (float)$row['price'];

            $data[] = array(
                'id'                => $pid,
                'name'              => $name,
                'description'       => $this->decodeHtml($this->safe($row, 'description', '')),
                'short_description' => $this->decodeHtml($rt),
                'status'            => $row['status'] ? 'publish' : 'draft',
                'price'             => $price,
                'sale_price'        => $sale,
                'sku'               => $sku,
                'model'             => trim($this->safe($row, 'model', '')),
                'stock_quantity'    => max(0, (int)$row['quantity']),
                'stock_status'      => ((int)$row['quantity'] > 0) ? 'instock' : 'outofstock',
                'weight'            => (float)$row['weight'],
                'sort_order'        => (int)$row['sort_order'],
                'images'            => $images,
                'categories'        => $cats,
                'brand'             => $brand,
                'tags'              => $tags,
                'meta_title'        => $this->decodeHtml($this->safe($row, 'meta_title', '')),
                'meta_description'  => $this->decodeHtml($this->safe($row, 'meta_description', '')),
            );
        }

        $this->sendJson(array('total' => $total, 'page' => $page, 'limit' => $limit, 'pages' => $pages, 'products' => $data));
    }
}
