<?php
class ControllerToolTransfer extends Controller {
    public function index() {
        $token    = isset($this->session->data['user_token']) ? $this->session->data['user_token'] : '';
        $base_url = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' ? 'https' : 'http') . '://' . $_SERVER['HTTP_HOST'];
        $api_base = $base_url . '/index.php?route=api/transfer';
        $key      = 'AMB_TRANSFER_2026';
        $html = '<!DOCTYPE html><html><head><meta charset="UTF-8"><title>WooCommerce Transfer API</title>
<style>body{font-family:Arial,sans-serif;max-width:780px;margin:40px auto;background:#f0f2f5;padding:20px}
.card{background:#fff;border-radius:12px;padding:36px;box-shadow:0 4px 20px rgba(0,0,0,.08);margin-bottom:20px}
h1{color:#1a1a2e;font-size:22px;margin:0 0 6px}
.sub{color:#666;font-size:14px;margin-bottom:24px}
.lbl{font-size:11px;font-weight:bold;color:#999;text-transform:uppercase;letter-spacing:1px;margin:16px 0 6px}
.url{background:#f8f9fa;border:1px solid #dee2e6;border-radius:8px;padding:12px 16px;font-family:monospace;font-size:12px;color:#333;margin:6px 0;word-break:break-all}
.key{background:#fff3e0;border:2px solid #f39c12;border-radius:8px;padding:12px 16px;font-family:monospace;font-size:16px;color:#e65100;font-weight:bold;margin:6px 0}
.badge{display:inline-block;background:#e8f5e9;color:#2e7d32;font-size:12px;padding:3px 10px;border-radius:20px;margin:3px 2px}
.note{background:#e3f2fd;border-left:4px solid #2196f3;padding:14px 18px;border-radius:0 8px 8px 0;font-size:13px;color:#1565c0;margin-top:16px;line-height:1.8}
</style></head><body>
<div class="card">
<h1>&#x1F680; WooCommerce Transfer API v2</h1>
<p class="sub">Bulletproof OpenCart &#8594; WooCommerce migration API. Install the WordPress plugin and connect using the details below.</p>
<div class="lbl">&#x1F511; Secret API Key (copy this into WordPress plugin)</div>
<div class="key">' . $key . '</div>
<div class="lbl">Store URL (copy this into WordPress plugin)</div>
<div class="url">' . $base_url . '</div>
<div class="lbl">API Endpoints (for reference)</div>
<div class="url">' . $api_base . '/index&amp;key=' . $key . '</div>
<div class="url">' . $api_base . '/stats&amp;key=' . $key . '</div>
<div class="url">' . $api_base . '/categories&amp;key=' . $key . '&amp;page=1&amp;limit=200</div>
<div class="url">' . $api_base . '/products&amp;key=' . $key . '&amp;page=1&amp;limit=50</div>
<div class="note">
<strong>&#x2705; What this API exports:</strong><br>
<span class="badge">Name</span><span class="badge">Full description (decoded HTML)</span><span class="badge">Price + Sale price</span>
<span class="badge">Stock qty + status</span><span class="badge">SKU (unique, from model)</span><span class="badge">All images (HTTPS encoded)</span>
<span class="badge">Categories with hierarchy</span><span class="badge">Brand/Manufacturer</span><span class="badge">Tags</span>
<span class="badge">Meta title/description</span><span class="badge">Weight</span>
</div>
<div class="note" style="background:#fff3e0;border-color:#f39c12;color:#7d4600;margin-top:10px">
<strong>&#x26A0; Security:</strong> Keep your API key private. If you want to change it, edit the <code>$secret</code> variable in <code>catalog/controller/api/transfer.php</code>
</div>
</div></body></html>';
        $this->response->setOutput($html);
    }
}
